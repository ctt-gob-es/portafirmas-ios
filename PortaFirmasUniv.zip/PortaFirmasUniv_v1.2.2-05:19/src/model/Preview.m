//
//  Preview.m
//  TopSongs
//
//  Created by Antonio Fiñana on 31/10/12.
//
//

#import "Preview.h"

@implementation Preview
@synthesize name,data,docid,mmtp,errorCode,errorMsg;

@end
