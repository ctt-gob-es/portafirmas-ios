//
//  Reject.m
//  WSFirmaClient
//
//  Created by Antonio Fiñana on 05/11/12.
//
//

#import "PFRequestResult.h"

@implementation PFRequestResult
@synthesize rejectid, status, errorCode, errorMsg;

@end
