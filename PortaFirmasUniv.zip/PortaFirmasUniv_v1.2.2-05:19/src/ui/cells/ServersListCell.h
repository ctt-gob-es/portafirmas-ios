//
//  ServersListCell.h
//  PortaFirmasUniv
//
//  Created by Rocio Tovar on 17/3/15.
//  Copyright (c) 2015 Atos. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServersListCell : UITableViewCell

- (void)setServerInfo:(NSDictionary *)serverInfo;

@end
